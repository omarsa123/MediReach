import type { Request, Response } from "express";
import { AdminModel } from "./admin.model.js";
import { catchAsync } from "../../utils/catchAsync.js";
import {
  paginationMeta,
  parsePagination,
} from "../../utils/pagination.utils.js";
import { errorResponse, successResponse } from "../../utils/response.utils.js";
import { AuthService } from "../authUser/auth.service.js";

export class AdminController {
  // Legacy mobile API compatibility
  static legacyStats = catchAsync(async (_req: Request, res: Response) => {
    const stats: any = await AdminModel.dashboardStats();
    const orgs = await AdminModel.listOrganizations();
    const count = (type: string) =>
      orgs.filter((o: any) => o.organizerType === type).length;
    res.json(
      successResponse({
        ...stats,
        totalHospitals: count("Hospital"),
        totalClinics: count("Clinic"),
        totalLabs: count("Lab"),
        totalPhysio: count("PhysiotherapyCenter"),
        pendingCount: stats.pendingOrganizations,
      }),
    );
  });

  static legacyPendingOrganizations = catchAsync(
    async (_req: Request, res: Response) => {
      const organizations = await AdminModel.listPendingOrganizations();
      res.json(
        successResponse(
          organizations,
          "Pending organizations retrieved successfully",
        ),
      );
    },
  );

  static legacyVerifyOrganization = catchAsync(
    async (req: Request, res: Response) => {
      const { organizationId, status } = req.body || {};
      if (!organizationId || !["Approved", "Rejected"].includes(status)) {
        res
          .status(400)
          .json(
            errorResponse(
              "organizationId and valid status are required",
              "INVALID_INPUT",
            ),
          );
        return;
      }
      const organization = await AdminModel.updateOrganizationVerification(
        organizationId,
        status,
      );
      if (!organization) {
        res
          .status(404)
          .json(errorResponse("Organization not found", "NOT_FOUND"));
        return;
      }
      res.json(
        successResponse(
          organization,
          `Organization has been ${status.toLowerCase()} successfully`,
        ),
      );
    },
  );

  static legacyOrganizations = catchAsync(
    async (req: Request, res: Response) => {
      const organizations = await AdminModel.listOrganizations(
        req.query.type as string | undefined,
      );
      res.json(
        successResponse(organizations, "Organizations retrieved successfully"),
      );
    },
  );

  static legacyToggleUserStatus = catchAsync(
    async (req: Request, res: Response) => {
      const { userId, status } = req.body || {};
      if (!userId || !["Active", "Suspended"].includes(status)) {
        res
          .status(400)
          .json(
            errorResponse(
              "userId and valid status are required",
              "INVALID_INPUT",
            ),
          );
        return;
      }
      const user = await AdminModel.updateUserStatus(userId, status);
      if (!user) {
        res.status(404).json(errorResponse("User not found", "NOT_FOUND"));
        return;
      }
      res.json(successResponse(user, `User status changed to ${status}`));
    },
  );

  static dashboard = catchAsync(
    async (_req: Request, res: Response): Promise<void> => {
      const stats = await AdminModel.dashboardStats();
      res.json(successResponse({ stats }));
    },
  );

  static listPendingProviders = catchAsync(
    async (_req: Request, res: Response): Promise<void> => {
      const providers = await AdminModel.listPendingProviders();
      res.json(successResponse({ providers }));
    },
  );

  static updateProviderVerification = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      const { status } = req.body;
      const allowed = ["Pending", "Approved", "Rejected"];
      if (!status || !allowed.includes(status)) {
        res
          .status(400)
          .json(
            errorResponse(
              `status must be one of: ${allowed.join(", ")}`,
              "INVALID_STATUS",
            ),
          );
        return;
      }
      const provider = await AdminModel.updateProviderVerification(
        String(req.params.providerId || ""),
        status,
      );
      if (!provider) {
        res.status(404).json(errorResponse("Provider not found", "NOT_FOUND"));
        return;
      }
      res.json(successResponse({ provider }, "Provider verification updated"));
    },
  );

  static listPendingOrganizations = catchAsync(
    async (_req: Request, res: Response): Promise<void> => {
      const organizations = await AdminModel.listPendingOrganizations();
      res.json(successResponse({ organizations }));
    },
  );

  static updateOrganizationVerification = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      const { status } = req.body;
      const allowed = ["Pending", "Approved", "Rejected"];
      if (!status || !allowed.includes(status)) {
        res
          .status(400)
          .json(
            errorResponse(
              `status must be one of: ${allowed.join(", ")}`,
              "INVALID_STATUS",
            ),
          );
        return;
      }
      const organization = await AdminModel.updateOrganizationVerification(
        String(req.params.organizationId || ""),
        status,
      );
      if (!organization) {
        res
          .status(404)
          .json(errorResponse("Organization not found", "NOT_FOUND"));
        return;
      }
      res.json(
        successResponse({ organization }, "Organization verification updated"),
      );
    },
  );

  static listUsers = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      const status =
        (req.query.status as string | undefined)?.trim() || undefined;
      const role = (req.query.role as string | undefined)?.trim() || undefined;
      const search =
        (req.query.search as string | undefined)?.trim() || undefined;
      const { page, limit, offset } = parsePagination(req.query);
      const { users, total } = await AdminModel.listUsers({
        status,
        role,
        search,
        limit,
        offset,
      });
      res.json(
        successResponse({
          users,
          pagination: paginationMeta(total, page, limit),
        }),
      );
    },
  );

  static updateUserStatus = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      const { status } = req.body;
      const allowed = ["Active", "Inactive", "Suspended"];
      if (!status || !allowed.includes(status)) {
        res
          .status(400)
          .json(
            errorResponse(
              `status must be one of: ${allowed.join(", ")}`,
              "INVALID_STATUS",
            ),
          );
        return;
      }
      const user = await AdminModel.updateUserStatus(
        String(req.params.userId || ""),
        status,
      );
      if (!user) {
        res.status(404).json(errorResponse("User not found", "NOT_FOUND"));
        return;
      }
      res.json(successResponse({ user }, "User status updated"));
    },
  );
  static registerAccount = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      try {
        const result = await AuthService.register(req.body || {}, {
          skipEmailVerification: true,
        });
        res
          .status(201)
          .json(successResponse(result, "Account created successfully."));
      } catch (err: any) {
        const status = Number(err?.status ?? err?.statusCode);
        const httpStatus =
          Number.isInteger(status) && status >= 400 && status < 600
            ? status
            : 500;
        res
          .status(httpStatus)
          .json(
            errorResponse(
              err?.message || "Registration failed",
              err?.code || "REGISTER_FAILED",
              err?.data,
            ),
          );
      }
    },
  );

  static hardDeleteUser = catchAsync(
    async (req: Request, res: Response): Promise<void> => {
      const email = String(req.body?.email || req.query?.email || "").trim();
      if (!email) {
        res
          .status(400)
          .json(
            errorResponse("Email is required for deletion", "MISSING_EMAIL"),
          );
        return;
      }

      // استدعاء دالة الحذف الجذري من AuthService لضمان مسحه من Supabase والداتابيز
      const result = await AuthService.hardDeleteUser(email);
      res.json(
        successResponse(
          result,
          "User deleted permanently from system and auth",
        ),
      );
    },
  );
}
