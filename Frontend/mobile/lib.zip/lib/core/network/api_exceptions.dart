class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final String? code;

  const ApiException({
    required this.message,
    this.statusCode,
    this.code,
  });

  @override
  String toString() => message;
}

class NetworkException extends ApiException {
  const NetworkException({super.message = 'Cannot connect to server. Please check your connection.'})
      : super(statusCode: null, code: 'NETWORK_ERROR');
}

class UnauthorizedException extends ApiException {
  const UnauthorizedException({super.message = 'Unauthorized. Please sign in again.'})
      : super(statusCode: 401, code: 'UNAUTHORIZED');
}

class RoleMismatchException extends ApiException {
  final String expectedRole;
  final String actualRole;

  const RoleMismatchException({
    required super.message,
    required this.expectedRole,
    required this.actualRole,
  }) : super(statusCode: 403, code: 'ROLE_MISMATCH');
}
